import React from 'react';
import MainNavigator from './src/navigation/MainNavigator'; // Dùng điều hướng chính

export default function App() {
  return <MainNavigator />;
}
